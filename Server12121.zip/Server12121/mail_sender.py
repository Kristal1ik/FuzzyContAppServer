import smtplib
from email.mime.text import MIMEText
from email.utils import make_msgid
data = input()
email = input()
s = smtplib.SMTP('smtp.yandex.ru', 587)
s.ehlo()
s.starttls()
text = MIMEText(f"{data}", 'plain', "utf-8")
text['Message-ID'] =  make_msgid()
text['From'] = "fuzzymaxwell@yandex.ru"
text['To'] = email
text['Subject'] = "Registration"
s.login("fuzzymaxwell@yandex.ru", "lcegflpdfhwreftr")
s.sendmail("fuzzymaxwell@yandex.ru", email, text.as_string())
s.quit()

