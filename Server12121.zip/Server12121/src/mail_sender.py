import smtplib
from email.mime.text import MIMEText
data = input()
email = input()
s = smtplib.SMTP('smtp.yandex.ru', 587)
s.ehlo()
s.starttls()
s.login("fuzzymaxwell@yandex.ru", "lcegflpdfhwreftr")
s.sendmail("fuzzymaxwell@yandex.ru", email, f"""From: <fuzzymaxwell@yandex.ru>
To: <{email}>
Subject: <Registration>
{data}""")
s.quit()

