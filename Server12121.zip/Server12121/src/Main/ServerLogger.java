//package Main;
//import java.util.logging.*;
//import java.io.IOException;
//import java.io.*;
//public class ServerLogger {
//	private final static Logger ServerLogger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
//	public static void logINFO(String s) {
//		ServerLogger.log(Level.INFO, s);
//	}
//	public static void logWARNING (String s) {
//		ServerLogger.log(Level.WARNING, s);
//	}
//	public static void logCRITICAL(String s) {
//		ServerLogger.log(Level.SEVERE, s);
//	}
//}
