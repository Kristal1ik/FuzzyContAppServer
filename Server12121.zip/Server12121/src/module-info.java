/**
 * 
 */
/**
 * @author Sasha Loza
 *
 */
module Server {
	requires java.sql;
	requires java.logging;
}